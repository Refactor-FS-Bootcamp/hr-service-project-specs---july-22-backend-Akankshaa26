class Filter {
    constructor() {
        
        this.conditions = []; 

    }
};

module.exports=Filter;