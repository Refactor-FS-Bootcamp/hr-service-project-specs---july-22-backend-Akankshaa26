
 class RequestModel {


    constructor() {
        this.client_id = '';
        this.dataCollection=[]; 

    }
};

module.exports=RequestModel;