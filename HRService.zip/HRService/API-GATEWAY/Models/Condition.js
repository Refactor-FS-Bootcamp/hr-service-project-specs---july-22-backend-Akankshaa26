
export default class Condition {


    constructor() {
        this.field_name = '';
        this.field_value = '';
        this.operator = '';  

    }
};

module.exports=Condition;