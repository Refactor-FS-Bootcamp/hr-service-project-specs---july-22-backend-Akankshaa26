"use strict";
exports.__esModule = true;
exports.DtoBase = void 0;
var DtoBase = /** @class */ (function () {
    function DtoBase() {
        this.id = 0;
    }
    return DtoBase;
}());
exports.DtoBase = DtoBase;
