

export class DtoBase{

    constructor(){
        this.id = 0;
    }

    id:number;
}