"use strict";
exports.__esModule = true;
var RequestModelQuery = /** @class */ (function () {
    function RequestModelQuery() {
        this.dataCollection = new Array();
    }
    return RequestModelQuery;
}());
exports["default"] = RequestModelQuery;
