
class RequestModel {


    constructor() {
        this.client_id = '';
        /**
         * This will be the collection on which operation (add/update) will take place
         */
        this.dataCollection=[]; 

    }
};

export default RequestModel;