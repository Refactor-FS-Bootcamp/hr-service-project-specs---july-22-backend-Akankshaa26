class PageInfo{
    constructor(){
        this.limit = 5;
        this.total_records = 0;
        this.offset = 0;
    }
};

module.exports=PageInfo;