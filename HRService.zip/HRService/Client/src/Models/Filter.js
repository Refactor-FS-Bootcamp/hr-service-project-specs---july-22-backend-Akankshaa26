class Filter {
    constructor() {
        
        this.conditions = []; //this will hold array of conditons

    }
};

module.exports = Filter;
//export default Filter;